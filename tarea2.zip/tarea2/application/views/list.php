<?php plantilla::aplicar(); ?>

<h3>Listado de personas agregadas</h3>

<table class='table'>
    <thead>
        <tr>

              <th>Cedula</th>
              <th>Fecha<th>
              <th>Nombre</th>
              <th>Apellido</th>
              <th>Genero</th>
              <th>Tipo de Sangre</th>
</tr>
</thead>      
<tbody>
    <tr>
        <td>344545</td>
        <td>2019</td>
        <td>Ubi</td>
        <td>Garcia</td>
        <td>Femenino</td>
        <td>B+</td>
        <td>
            <a href='' class='btn btn-danger'>X</a>
</tr>
</tbody>

</table>