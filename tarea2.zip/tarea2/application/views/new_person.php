<?php plantilla::aplicar(); 

    function asgInput($nombre, $label, $valor=''){
        return <<<CODIGO
        <div class="form-group input-group">
               <label>{label}:</label>
               <input type='text' value='{$valor}' class='form-control' name='{nombre'}/>
   </div>
            }


?>

<h3>Editar Persona</h3>
<form method="post" action="">
    <div class='row'>
        <div class='col-md-6'>

        <?= $nombre ?>



        </div>

    </div>